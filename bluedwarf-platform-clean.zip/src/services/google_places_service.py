import json
import os
import requests
from typing import List, Dict, Optional

class GooglePlacesService:
    """Service for searching real professionals using Google Places API"""
    
    def __init__(self):
        # Use the real Google Places API key
        self.api_key = os.getenv('GOOGLE_PLACES_API_KEY', 'AIzaSyDe8QxfkBSo2Ids9PWK24-aKgqbI9du9B4')
        self.base_url = "https://places.googleapis.com/v1/places:searchNearby"
        
        # Professional category mapping to Google Place types
        self.category_mapping = {
            'agent': {
                'google_type': 'real_estate_agency',
                'keywords': ['real estate', 'realtor', 'realty', 'homes', 'properties', 'keller williams', 'coldwell banker', 're/max'],
                'title': 'Real Estate Agent'
            },
            'lender': {
                'google_type': 'bank',
                'keywords': ['mortgage', 'lending', 'loan', 'credit union', 'bank', 'wells fargo', 'chase', 'bank of america'],
                'title': 'Mortgage Lender'
            },
            'attorney': {
                'google_type': 'lawyer',
                'keywords': ['real estate law', 'property law', 'title', 'legal', 'attorney', 'law firm', 'legal services'],
                'title': 'Real Estate Attorney'
            },
            'title': {
                'google_type': 'insurance_agency',
                'keywords': ['title insurance', 'title company', 'escrow', 'closing', 'title services', 'first american', 'chicago title'],
                'title': 'Title Officer'
            }
        }
    
    def search_professionals(self, latitude: float, longitude: float, category: str, radius: int = 10000) -> List[Dict]:
        """
        Search for real professionals using Google Places API
        
        Args:
            latitude: Search center latitude
            longitude: Search center longitude  
            category: Professional category (agent, lender, attorney, title)
            radius: Search radius in meters (default 10km)
            
        Returns:
            List of place data from Google Places API
        """
        
        if category not in self.category_mapping:
            raise ValueError(f"Unknown category: {category}")
        
        place_type = self.category_mapping[category]['google_type']
        
        # Use real Google Places API now that we have a valid key
        if self.api_key == 'DEMO_API_KEY':
            return self._get_demo_data(latitude, longitude, category)
        
        payload = {
            "includedTypes": [place_type],
            "maxResultCount": 20,
            "locationRestriction": {
                "circle": {
                    "center": {
                        "latitude": latitude,
                        "longitude": longitude
                    },
                    "radius": radius
                }
            }
        }
        
        headers = {
            "Content-Type": "application/json",
            "X-Goog-Api-Key": self.api_key,
            "X-Goog-FieldMask": "places.displayName,places.formattedAddress,places.nationalPhoneNumber,places.websiteUri,places.rating,places.userRatingCount,places.businessStatus,places.location"
        }
        
        try:
            response = requests.post(self.base_url, json=payload, headers=headers)
            response.raise_for_status()
            
            data = response.json()
            return data.get('places', [])
            
        except requests.exceptions.RequestException as e:
            print(f"Error calling Google Places API: {e}")
            return []
    
    def _get_demo_data(self, latitude: float, longitude: float, category: str) -> List[Dict]:
        """
        Generate demo data that represents real Google Places API responses
        This simulates what real API calls would return for different locations
        """
        
        # Determine location context from coordinates
        location_context = self._get_location_context(latitude, longitude)
        
        demo_data = {
            'fair_oaks_ca': {
                'agent': [
                    {
                        'displayName': {'text': 'Keller Williams Fair Oaks'},
                        'formattedAddress': '8525 Madison Ave, Fair Oaks, CA 95628',
                        'nationalPhoneNumber': '(916) 965-7100',
                        'websiteUri': 'https://www.kwfairoaks.com',
                        'rating': 4.2,
                        'userRatingCount': 89,
                        'businessStatus': 'OPERATIONAL'
                    },
                    {
                        'displayName': {'text': 'Lyon Real Estate Fair Oaks'},
                        'formattedAddress': '10267 Fair Oaks Blvd, Fair Oaks, CA 95628',
                        'nationalPhoneNumber': '(916) 961-3434',
                        'websiteUri': 'https://www.lyonrealestate.com',
                        'rating': 4.5,
                        'userRatingCount': 156,
                        'businessStatus': 'OPERATIONAL'
                    }
                ],
                'lender': [
                    {
                        'displayName': {'text': 'Golden 1 Credit Union Fair Oaks'},
                        'formattedAddress': '8051 Sunset Ave, Fair Oaks, CA 95628',
                        'nationalPhoneNumber': '(916) 732-2900',
                        'websiteUri': 'https://www.golden1.com',
                        'rating': 4.1,
                        'userRatingCount': 203,
                        'businessStatus': 'OPERATIONAL'
                    },
                    {
                        'displayName': {'text': 'Wells Fargo Bank Fair Oaks'},
                        'formattedAddress': '7801 Madison Ave, Fair Oaks, CA 95628',
                        'nationalPhoneNumber': '(916) 967-2850',
                        'websiteUri': 'https://www.wellsfargo.com',
                        'rating': 3.8,
                        'userRatingCount': 127,
                        'businessStatus': 'OPERATIONAL'
                    }
                ],
                'attorney': [
                    {
                        'displayName': {'text': 'Sacramento Real Estate Law Group'},
                        'formattedAddress': '9719 Lincoln Village Dr, Sacramento, CA 95827',
                        'nationalPhoneNumber': '(916) 333-4567',
                        'websiteUri': 'https://www.sacrealestatelaw.com',
                        'rating': 4.7,
                        'userRatingCount': 94,
                        'businessStatus': 'OPERATIONAL'
                    }
                ],
                'title': [
                    {
                        'displayName': {'text': 'First American Title Fair Oaks'},
                        'formattedAddress': '8280 Madison Ave, Fair Oaks, CA 95628',
                        'nationalPhoneNumber': '(916) 961-7500',
                        'websiteUri': 'https://www.firstam.com',
                        'rating': 4.3,
                        'userRatingCount': 78,
                        'businessStatus': 'OPERATIONAL'
                    }
                ]
            },
            'billings_mt': {
                'agent': [
                    {
                        'displayName': {'text': 'eXp Realty Billings'},
                        'formattedAddress': '2900 12th Ave N, Billings, MT 59101',
                        'nationalPhoneNumber': '(406) 294-4663',
                        'websiteUri': 'https://www.exprealty.com',
                        'rating': 4.6,
                        'userRatingCount': 142,
                        'businessStatus': 'OPERATIONAL'
                    },
                    {
                        'displayName': {'text': 'Century 21 Billings'},
                        'formattedAddress': '1834 King Ave W, Billings, MT 59102',
                        'nationalPhoneNumber': '(406) 652-4663',
                        'websiteUri': 'https://www.century21.com',
                        'rating': 4.2,
                        'userRatingCount': 98,
                        'businessStatus': 'OPERATIONAL'
                    }
                ],
                'lender': [
                    {
                        'displayName': {'text': 'First Interstate Bank Billings'},
                        'formattedAddress': '401 N 31st St, Billings, MT 59101',
                        'nationalPhoneNumber': '(406) 255-5200',
                        'websiteUri': 'https://www.firstinterstate.com',
                        'rating': 4.0,
                        'userRatingCount': 167,
                        'businessStatus': 'OPERATIONAL'
                    }
                ],
                'attorney': [
                    {
                        'displayName': {'text': 'Billings Real Estate Law'},
                        'formattedAddress': '2900 4th Ave N, Billings, MT 59101',
                        'nationalPhoneNumber': '(406) 248-7171',
                        'websiteUri': 'https://www.billingslaw.com',
                        'rating': 4.4,
                        'userRatingCount': 67,
                        'businessStatus': 'OPERATIONAL'
                    }
                ],
                'title': [
                    {
                        'displayName': {'text': 'Montana Title & Escrow Billings'},
                        'formattedAddress': '2821 2nd Ave N, Billings, MT 59101',
                        'nationalPhoneNumber': '(406) 245-5577',
                        'websiteUri': 'https://www.mttitle.com',
                        'rating': 4.5,
                        'userRatingCount': 89,
                        'businessStatus': 'OPERATIONAL'
                    }
                ]
            }
        }
        
        return demo_data.get(location_context, {}).get(category, [])
    
    def _get_location_context(self, latitude: float, longitude: float) -> str:
        """Determine location context from coordinates"""
        
        # Fair Oaks, CA area (38.7223, -121.3018)
        if 38.6 < latitude < 38.8 and -121.5 < longitude < -121.1:
            return 'fair_oaks_ca'
        
        # Billings, MT area (45.7833, -108.5007)  
        if 45.6 < latitude < 45.9 and -108.7 < longitude < -108.3:
            return 'billings_mt'
        
        # Default to Fair Oaks for demo
        return 'fair_oaks_ca'
    
    def filter_by_category(self, places: List[Dict], category: str) -> List[Dict]:
        """Filter places to match professional category keywords"""
        
        if category not in self.category_mapping:
            return places
        
        keywords = self.category_mapping[category]['keywords']
        filtered = []
        
        for place in places:
            name = place.get('displayName', {}).get('text', '').lower()
            
            # Check if business name contains relevant keywords
            if any(keyword in name for keyword in keywords):
                filtered.append(place)
        
        # If no keyword matches, return all places (they came from the right category search)
        return filtered if filtered else places
    
    def select_best_professionals(self, places: List[Dict], count: int = 4) -> List[Dict]:
        """Select the best professionals based on ratings and reviews"""
        
        # Sort by rating and review count
        sorted_places = sorted(
            places,
            key=lambda x: (
                x.get('rating', 0),
                x.get('userRatingCount', 0)
            ),
            reverse=True
        )
        
        return sorted_places[:count]

