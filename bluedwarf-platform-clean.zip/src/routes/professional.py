from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import sys
import os

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from src.models.professional import db, Professional, Lead

professional_bp = Blueprint('professional', __name__)

@professional_bp.route('/register', methods=['POST'])
def register_professional():
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['firstName', 'lastName', 'email', 'password', 'professionalType', 'plan']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Check if email already exists
        existing_professional = Professional.query.filter_by(email=data['email']).first()
        if existing_professional:
            return jsonify({'error': 'Email already registered'}), 400
        
        # Set subscription details based on plan
        plan_details = {
            'starter': {'max_territories': 1, 'price': 97},
            'professional': {'max_territories': 3, 'price': 197},
            'enterprise': {'max_territories': 999, 'price': 397}
        }
        
        plan = data['plan']
        if plan not in plan_details:
            return jsonify({'error': 'Invalid plan selected'}), 400
        
        # Create new professional
        professional = Professional(
            email=data['email'],
            password_hash=generate_password_hash(data['password']),
            first_name=data['firstName'],
            last_name=data['lastName'],
            professional_type=data['professionalType'],
            subscription_plan=plan,
            max_territories=plan_details[plan]['max_territories'],
            subscription_start=datetime.utcnow(),
            subscription_end=datetime.utcnow() + timedelta(days=30),  # 30-day trial
            # Temporary values - will be updated in onboarding
            company_name=f"{data['firstName']} {data['lastName']} {data['professionalType'].title()}",
            phone="(555) 000-0000",
            business_address="TBD",
            city="TBD",
            state="TBD",
            zip_code="00000"
        )
        
        db.session.add(professional)
        db.session.commit()
        
        return jsonify({
            'message': 'Professional registered successfully',
            'professional_id': professional.id,
            'subscription_plan': plan,
            'trial_end': professional.subscription_end.isoformat()
        }), 201
        
    except Exception as e:
        print(f"Error registering professional: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@professional_bp.route('/login', methods=['POST'])
def login_professional():
    try:
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')
        
        if not email or not password:
            return jsonify({'error': 'Email and password are required'}), 400
        
        professional = Professional.query.filter_by(email=email).first()
        
        if not professional or not check_password_hash(professional.password_hash, password):
            return jsonify({'error': 'Invalid email or password'}), 401
        
        if not professional.is_active:
            return jsonify({'error': 'Account is deactivated'}), 401
        
        # Update last login
        professional.last_login = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Login successful',
            'professional': professional.to_dict()
        }), 200
        
    except Exception as e:
        print(f"Error logging in professional: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@professional_bp.route('/<int:professional_id>', methods=['GET'])
def get_professional(professional_id):
    try:
        professional = Professional.query.get(professional_id)
        if not professional:
            return jsonify({'error': 'Professional not found'}), 404
        
        return jsonify(professional.to_dict()), 200
        
    except Exception as e:
        print(f"Error getting professional: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@professional_bp.route('/<int:professional_id>', methods=['PUT'])
def update_professional(professional_id):
    try:
        professional = Professional.query.get(professional_id)
        if not professional:
            return jsonify({'error': 'Professional not found'}), 404
        
        data = request.get_json()
        
        # Update allowed fields
        allowed_fields = [
            'first_name', 'last_name', 'company_name', 'license_number', 
            'phone', 'business_address', 'city', 'state', 'zip_code',
            'bio', 'website', 'linkedin'
        ]
        
        for field in allowed_fields:
            if field in data:
                setattr(professional, field, data[field])
        
        # Handle territory zip codes
        if 'territory_zip_codes' in data:
            zip_codes = data['territory_zip_codes']
            if len(zip_codes) > professional.max_territories:
                return jsonify({
                    'error': f'Cannot select more than {professional.max_territories} territories for your plan'
                }), 400
            professional.set_territory_zip_codes(zip_codes)
        
        professional.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Professional updated successfully',
            'professional': professional.to_dict()
        }), 200
        
    except Exception as e:
        print(f"Error updating professional: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@professional_bp.route('/<int:professional_id>/leads', methods=['GET'])
def get_professional_leads(professional_id):
    try:
        professional = Professional.query.get(professional_id)
        if not professional:
            return jsonify({'error': 'Professional not found'}), 404
        
        leads = Lead.query.filter_by(professional_id=professional_id).order_by(Lead.created_at.desc()).all()
        
        return jsonify({
            'leads': [lead.to_dict() for lead in leads],
            'total_leads': len(leads)
        }), 200
        
    except Exception as e:
        print(f"Error getting professional leads: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@professional_bp.route('/leads', methods=['POST'])
def create_lead():
    try:
        data = request.get_json()
        
        required_fields = ['professional_id', 'property_address', 'property_city', 'property_state', 'property_zip_code']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Verify professional exists
        professional = Professional.query.get(data['professional_id'])
        if not professional:
            return jsonify({'error': 'Professional not found'}), 404
        
        # Create new lead
        lead = Lead(
            professional_id=data['professional_id'],
            property_address=data['property_address'],
            property_city=data['property_city'],
            property_state=data['property_state'],
            property_zip_code=data['property_zip_code'],
            property_value=data.get('property_value'),
            source=data.get('source', 'property_search'),
            user_ip=request.remote_addr,
            user_agent=request.headers.get('User-Agent', '')
        )
        
        db.session.add(lead)
        
        # Update professional lead count
        professional.leads_received += 1
        
        db.session.commit()
        
        return jsonify({
            'message': 'Lead created successfully',
            'lead': lead.to_dict()
        }), 201
        
    except Exception as e:
        print(f"Error creating lead: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@professional_bp.route('/search', methods=['GET'])
def search_professionals():
    try:
        zip_code = request.args.get('zip_code')
        professional_type = request.args.get('type')
        
        query = Professional.query.filter_by(is_active=True)
        
        if zip_code:
            # Search professionals who have this zip code in their territories
            query = query.filter(Professional.territory_zip_codes.contains(f'"{zip_code}"'))
        
        if professional_type:
            query = query.filter_by(professional_type=professional_type)
        
        professionals = query.limit(10).all()
        
        return jsonify({
            'professionals': [prof.to_dict() for prof in professionals],
            'total': len(professionals)
        }), 200
        
    except Exception as e:
        print(f"Error searching professionals: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

