"""
Property Value Estimator
Generates realistic property values based on US regional market conditions
"""

import random
from typing import Dict

class PropertyValueEstimator:
    """Estimates property values based on location and market conditions"""
    
    def __init__(self):
        # State-based property value multipliers (relative to national average)
        self.state_multipliers = {
            # High-cost states
            'CA': 2.8,  # California - very high
            'HI': 2.5,  # Hawaii - very high
            'NY': 2.2,  # New York - high
            'MA': 2.0,  # Massachusetts - high
            'WA': 1.9,  # Washington - high
            'NJ': 1.8,  # New Jersey - high
            'CT': 1.7,  # Connecticut - high
            'MD': 1.6,  # Maryland - above average
            'CO': 1.5,  # Colorado - above average
            'OR': 1.4,  # Oregon - above average
            'RI': 1.4,  # Rhode Island - above average
            'NH': 1.3,  # New Hampshire - above average
            'VA': 1.3,  # Virginia - above average
            'VT': 1.2,  # Vermont - above average
            'DE': 1.2,  # Delaware - above average
            'FL': 1.1,  # Florida - slightly above average
            'AZ': 1.1,  # Arizona - slightly above average
            'NV': 1.1,  # Nevada - slightly above average
            'UT': 1.1,  # Utah - slightly above average
            'ME': 1.0,  # Maine - average
            'TX': 1.0,  # Texas - average (baseline)
            'NC': 1.0,  # North Carolina - average
            'GA': 0.95, # Georgia - slightly below average
            'SC': 0.9,  # South Carolina - below average
            'TN': 0.9,  # Tennessee - below average
            'PA': 0.9,  # Pennsylvania - below average
            'IL': 0.9,  # Illinois - below average
            'MI': 0.85, # Michigan - below average
            'OH': 0.8,  # Ohio - below average
            'IN': 0.8,  # Indiana - below average
            'MO': 0.8,  # Missouri - below average
            'WI': 0.8,  # Wisconsin - below average
            'MN': 0.8,  # Minnesota - below average
            'AL': 0.75, # Alabama - low
            'KY': 0.75, # Kentucky - low
            'LA': 0.75, # Louisiana - low
            'MS': 0.7,  # Mississippi - low
            'AR': 0.7,  # Arkansas - low
            'OK': 0.7,  # Oklahoma - low
            'KS': 0.7,  # Kansas - low
            'NE': 0.7,  # Nebraska - low
            'IA': 0.7,  # Iowa - low
            'SD': 0.65, # South Dakota - low
            'ND': 0.65, # North Dakota - low
            'MT': 0.65, # Montana - low
            'WY': 0.65, # Wyoming - low
            'ID': 0.65, # Idaho - low
            'NM': 0.65, # New Mexico - low
            'WV': 0.6,  # West Virginia - very low
            'AK': 1.2,  # Alaska - above average (remote premium)
            'DC': 2.0   # Washington DC - high
        }
        
        # Base property value (national average)
        self.base_value = 350000
        
        # City size multipliers
        self.city_size_multipliers = {
            'major_metro': 1.3,     # Major metropolitan areas
            'large_city': 1.1,      # Large cities
            'medium_city': 1.0,     # Medium cities (baseline)
            'small_city': 0.9,      # Small cities
            'rural': 0.7            # Rural areas
        }
        
        # Major metropolitan areas (higher property values)
        self.major_metros = {
            'CA': ['Los Angeles', 'San Francisco', 'San Diego', 'San Jose', 'Oakland', 'Fremont', 'Santa Ana', 'Anaheim', 'Riverside', 'Stockton'],
            'NY': ['New York', 'Buffalo', 'Rochester', 'Yonkers', 'Syracuse', 'Albany', 'New Rochelle', 'Mount Vernon'],
            'TX': ['Houston', 'San Antonio', 'Dallas', 'Austin', 'Fort Worth', 'El Paso', 'Arlington', 'Corpus Christi', 'Plano', 'Laredo'],
            'FL': ['Jacksonville', 'Miami', 'Tampa', 'Orlando', 'St. Petersburg', 'Hialeah', 'Tallahassee', 'Fort Lauderdale', 'Port St. Lucie', 'Cape Coral'],
            'IL': ['Chicago', 'Aurora', 'Rockford', 'Joliet', 'Naperville', 'Springfield', 'Peoria', 'Elgin', 'Waukegan'],
            'PA': ['Philadelphia', 'Pittsburgh', 'Allentown', 'Erie', 'Reading', 'Scranton', 'Bethlehem', 'Lancaster'],
            'OH': ['Columbus', 'Cleveland', 'Cincinnati', 'Toledo', 'Akron', 'Dayton', 'Parma', 'Canton'],
            'GA': ['Atlanta', 'Augusta', 'Columbus', 'Savannah', 'Athens', 'Sandy Springs', 'Roswell', 'Macon'],
            'NC': ['Charlotte', 'Raleigh', 'Greensboro', 'Durham', 'Winston-Salem', 'Fayetteville', 'Cary', 'Wilmington'],
            'MI': ['Detroit', 'Grand Rapids', 'Warren', 'Sterling Heights', 'Lansing', 'Ann Arbor', 'Flint', 'Dearborn'],
            'WA': ['Seattle', 'Spokane', 'Tacoma', 'Vancouver', 'Bellevue', 'Kent', 'Everett', 'Renton'],
            'AZ': ['Phoenix', 'Tucson', 'Mesa', 'Chandler', 'Glendale', 'Scottsdale', 'Gilbert', 'Tempe'],
            'MA': ['Boston', 'Worcester', 'Springfield', 'Lowell', 'Cambridge', 'New Bedford', 'Brockton', 'Quincy'],
            'CO': ['Denver', 'Colorado Springs', 'Aurora', 'Fort Collins', 'Lakewood', 'Thornton', 'Arvada', 'Westminster'],
            'OR': ['Portland', 'Eugene', 'Salem', 'Gresham', 'Hillsboro', 'Bend', 'Beaverton', 'Medford'],
            'NV': ['Las Vegas', 'Henderson', 'Reno', 'North Las Vegas', 'Sparks', 'Carson City'],
            'UT': ['Salt Lake City', 'West Valley City', 'Provo', 'West Jordan', 'Orem', 'Sandy', 'Ogden']
        }
    
    def get_city_size_category(self, city: str, state: str) -> str:
        """Determine city size category for property value calculation"""
        state_metros = self.major_metros.get(state, [])
        
        # Check if it's a major metro
        for metro in state_metros:
            if metro.lower() in city.lower() or city.lower() in metro.lower():
                return 'major_metro'
        
        # Simple heuristic based on common city name patterns
        city_lower = city.lower()
        
        # Large cities (common large city names)
        large_city_indicators = ['city', 'heights', 'beach', 'springs', 'valley', 'hills']
        if any(indicator in city_lower for indicator in large_city_indicators):
            return 'large_city'
        
        # Small cities/rural (common small place indicators)
        small_indicators = ['ville', 'town', 'burg', 'field', 'wood', 'dale', 'view']
        if any(indicator in city_lower for indicator in small_indicators):
            return 'small_city'
        
        # Default to medium city
        return 'medium_city'
    
    def estimate_property_value(self, city: str, state: str, county: str = None) -> int:
        """
        Estimate property value for a location
        
        Args:
            city: City name
            state: State code
            county: County name (optional)
            
        Returns:
            Estimated property value in dollars
        """
        # Get state multiplier
        state_multiplier = self.state_multipliers.get(state.upper(), 1.0)
        
        # Get city size multiplier
        city_size = self.get_city_size_category(city, state.upper())
        city_multiplier = self.city_size_multipliers[city_size]
        
        # Calculate base value
        estimated_value = self.base_value * state_multiplier * city_multiplier
        
        # Add some randomness (+/- 15%)
        variance = random.uniform(0.85, 1.15)
        estimated_value *= variance
        
        # Round to nearest $1000
        estimated_value = round(estimated_value / 1000) * 1000
        
        # Ensure minimum value
        estimated_value = max(estimated_value, 50000)
        
        return int(estimated_value)
    
    def get_market_description(self, value: int) -> str:
        """Get a market description based on property value"""
        if value >= 800000:
            return "Luxury Market"
        elif value >= 500000:
            return "Premium Market"
        elif value >= 300000:
            return "Strong Market"
        elif value >= 200000:
            return "Stable Market"
        else:
            return "Affordable Market"
    
    def get_monthly_rent_estimate(self, property_value: int) -> int:
        """Estimate monthly rent based on property value (1% rule approximation)"""
        monthly_rent = property_value * 0.008  # 0.8% of property value per month
        return round(monthly_rent / 50) * 50  # Round to nearest $50

