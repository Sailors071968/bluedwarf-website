from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class Professional(db.Model):
    __tablename__ = 'professionals'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    
    # Professional Information
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    company_name = db.Column(db.String(100), nullable=False)
    license_number = db.Column(db.String(50))
    phone = db.Column(db.String(20), nullable=False)
    
    # Professional Type
    professional_type = db.Column(db.String(20), nullable=False)  # agent, lender, attorney, title
    
    # Address Information
    business_address = db.Column(db.String(200), nullable=False)
    city = db.Column(db.String(50), nullable=False)
    state = db.Column(db.String(2), nullable=False)
    zip_code = db.Column(db.String(10), nullable=False)
    
    # Subscription Information
    subscription_plan = db.Column(db.String(20), default='trial')  # trial, basic, premium, enterprise
    subscription_status = db.Column(db.String(20), default='active')  # active, cancelled, expired
    subscription_start = db.Column(db.DateTime, default=datetime.utcnow)
    subscription_end = db.Column(db.DateTime)
    
    # Territory Management (JSON field for zip codes)
    territory_zip_codes = db.Column(db.Text)  # JSON array of zip codes
    max_territories = db.Column(db.Integer, default=1)  # Based on subscription plan
    
    # Profile Information
    bio = db.Column(db.Text)
    website = db.Column(db.String(200))
    linkedin = db.Column(db.String(200))
    profile_image = db.Column(db.String(200))
    
    # Statistics
    leads_received = db.Column(db.Integer, default=0)
    profile_views = db.Column(db.Integer, default=0)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    # Account Status
    is_verified = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    
    def __repr__(self):
        return f'<Professional {self.first_name} {self.last_name} - {self.professional_type}>'
    
    def get_territory_zip_codes(self):
        """Get territory zip codes as a list"""
        if self.territory_zip_codes:
            return json.loads(self.territory_zip_codes)
        return []
    
    def set_territory_zip_codes(self, zip_codes):
        """Set territory zip codes from a list"""
        self.territory_zip_codes = json.dumps(zip_codes)
    
    def get_full_name(self):
        """Get professional's full name"""
        return f"{self.first_name} {self.last_name}"
    
    def get_subscription_info(self):
        """Get subscription information"""
        return {
            'plan': self.subscription_plan,
            'status': self.subscription_status,
            'start_date': self.subscription_start.isoformat() if self.subscription_start else None,
            'end_date': self.subscription_end.isoformat() if self.subscription_end else None,
            'max_territories': self.max_territories
        }
    
    def to_dict(self):
        """Convert professional to dictionary"""
        return {
            'id': self.id,
            'email': self.email,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'full_name': self.get_full_name(),
            'company_name': self.company_name,
            'license_number': self.license_number,
            'phone': self.phone,
            'professional_type': self.professional_type,
            'business_address': self.business_address,
            'city': self.city,
            'state': self.state,
            'zip_code': self.zip_code,
            'subscription': self.get_subscription_info(),
            'territory_zip_codes': self.get_territory_zip_codes(),
            'bio': self.bio,
            'website': self.website,
            'linkedin': self.linkedin,
            'profile_image': self.profile_image,
            'leads_received': self.leads_received,
            'profile_views': self.profile_views,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'is_verified': self.is_verified,
            'is_active': self.is_active
        }


class Lead(db.Model):
    __tablename__ = 'leads'
    
    id = db.Column(db.Integer, primary_key=True)
    professional_id = db.Column(db.Integer, db.ForeignKey('professionals.id'), nullable=False)
    
    # Lead Information
    property_address = db.Column(db.String(200), nullable=False)
    property_city = db.Column(db.String(50), nullable=False)
    property_state = db.Column(db.String(2), nullable=False)
    property_zip_code = db.Column(db.String(10), nullable=False)
    property_value = db.Column(db.Integer)
    
    # Lead Source
    source = db.Column(db.String(50), default='property_search')  # property_search, direct, referral
    user_ip = db.Column(db.String(45))
    user_agent = db.Column(db.String(500))
    
    # Lead Status
    status = db.Column(db.String(20), default='new')  # new, contacted, qualified, converted, lost
    notes = db.Column(db.Text)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship
    professional = db.relationship('Professional', backref=db.backref('leads', lazy=True))
    
    def __repr__(self):
        return f'<Lead {self.property_address} for Professional {self.professional_id}>'
    
    def to_dict(self):
        """Convert lead to dictionary"""
        return {
            'id': self.id,
            'professional_id': self.professional_id,
            'property_address': self.property_address,
            'property_city': self.property_city,
            'property_state': self.property_state,
            'property_zip_code': self.property_zip_code,
            'property_value': self.property_value,
            'source': self.source,
            'status': self.status,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

