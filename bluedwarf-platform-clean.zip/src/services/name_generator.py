"""
Regional Professional Name Generator
Generates realistic professional names based on US regional demographics
"""

import random
from typing import List, Tuple

class ProfessionalNameGenerator:
    """Generates realistic professional names based on US regional demographics"""
    
    def __init__(self):
        # Regional name pools reflecting US demographics
        self.regional_names = {
            'northeast': {
                'first_names': [
                    'Michael', 'Jennifer', 'Christopher', 'Jessica', 'Matthew', 'Ashley',
                    'David', 'Sarah', 'Daniel', 'Amanda', 'James', 'Emily', 'Robert',
                    'Elizabeth', 'John', 'Nicole', 'Joseph', 'Samantha', 'Andrew', 'Rachel'
                ],
                'last_names': [
                    'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller',
                    'Davis', 'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Gonzalez',
                    'Wilson', 'Anderson', 'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin'
                ]
            },
            'southeast': {
                'first_names': [
                    'William', 'Mary', 'James', 'Patricia', 'Robert', 'Jennifer', 'John',
                    'Linda', 'Michael', 'Elizabeth', 'David', 'Barbara', 'Richard', 'Susan',
                    'Joseph', 'Jessica', 'Thomas', 'Sarah', 'Christopher', 'Karen'
                ],
                'last_names': [
                    'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Miller', 'Davis',
                    'Garcia', 'Rodriguez', 'Wilson', 'Martinez', 'Anderson', 'Taylor',
                    'Thomas', 'Hernandez', 'Moore', 'Martin', 'Jackson', 'Thompson', 'White'
                ]
            },
            'midwest': {
                'first_names': [
                    'Michael', 'Jennifer', 'Christopher', 'Jessica', 'Matthew', 'Ashley',
                    'Joshua', 'Amanda', 'Andrew', 'Sarah', 'Daniel', 'Stephanie', 'David',
                    'Nicole', 'James', 'Elizabeth', 'John', 'Heather', 'Robert', 'Melissa'
                ],
                'last_names': [
                    'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Miller', 'Davis',
                    'Garcia', 'Rodriguez', 'Wilson', 'Martinez', 'Anderson', 'Taylor',
                    'Thomas', 'Hernandez', 'Moore', 'Martin', 'Jackson', 'Thompson', 'White'
                ]
            },
            'southwest': {
                'first_names': [
                    'Jose', 'Maria', 'Juan', 'Ana', 'Luis', 'Carmen', 'Carlos', 'Rosa',
                    'Miguel', 'Elena', 'Antonio', 'Sofia', 'Francisco', 'Isabella', 'Manuel',
                    'Gabriela', 'Jesus', 'Alejandra', 'David', 'Adriana'
                ],
                'last_names': [
                    'Garcia', 'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Gonzalez',
                    'Perez', 'Sanchez', 'Ramirez', 'Cruz', 'Flores', 'Gomez', 'Diaz',
                    'Reyes', 'Morales', 'Ortiz', 'Gutierrez', 'Chavez', 'Ramos', 'Castillo'
                ]
            },
            'west': {
                'first_names': [
                    'Michael', 'Jennifer', 'Christopher', 'Jessica', 'Matthew', 'Ashley',
                    'David', 'Sarah', 'Daniel', 'Amanda', 'James', 'Emily', 'Andrew',
                    'Nicole', 'Joshua', 'Stephanie', 'Ryan', 'Melissa', 'Brandon', 'Amy'
                ],
                'last_names': [
                    'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller',
                    'Davis', 'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Gonzalez',
                    'Wilson', 'Anderson', 'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin'
                ]
            },
            'pacific': {
                'first_names': [
                    'David', 'Jennifer', 'Michael', 'Jessica', 'Christopher', 'Sarah',
                    'Daniel', 'Ashley', 'Matthew', 'Amanda', 'James', 'Emily', 'Andrew',
                    'Nicole', 'Ryan', 'Stephanie', 'Kevin', 'Melissa', 'Brandon', 'Amy'
                ],
                'last_names': [
                    'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller',
                    'Davis', 'Rodriguez', 'Martinez', 'Kim', 'Lee', 'Chen', 'Wang', 'Liu',
                    'Patel', 'Singh', 'Anderson', 'Thomas', 'Taylor'
                ]
            }
        }
        
        # State to region mapping
        self.state_to_region = {
            # Northeast
            'ME': 'northeast', 'NH': 'northeast', 'VT': 'northeast', 'MA': 'northeast',
            'RI': 'northeast', 'CT': 'northeast', 'NY': 'northeast', 'NJ': 'northeast',
            'PA': 'northeast',
            
            # Southeast
            'DE': 'southeast', 'MD': 'southeast', 'DC': 'southeast', 'VA': 'southeast',
            'WV': 'southeast', 'KY': 'southeast', 'TN': 'southeast', 'NC': 'southeast',
            'SC': 'southeast', 'GA': 'southeast', 'FL': 'southeast', 'AL': 'southeast',
            'MS': 'southeast', 'AR': 'southeast', 'LA': 'southeast',
            
            # Midwest
            'OH': 'midwest', 'MI': 'midwest', 'IN': 'midwest', 'WI': 'midwest',
            'IL': 'midwest', 'MN': 'midwest', 'IA': 'midwest', 'MO': 'midwest',
            'ND': 'midwest', 'SD': 'midwest', 'NE': 'midwest', 'KS': 'midwest',
            
            # Southwest
            'OK': 'southwest', 'TX': 'southwest', 'NM': 'southwest', 'AZ': 'southwest',
            'CO': 'southwest', 'UT': 'southwest', 'NV': 'southwest',
            
            # West
            'MT': 'west', 'WY': 'west', 'ID': 'west',
            
            # Pacific
            'WA': 'pacific', 'OR': 'pacific', 'CA': 'pacific', 'AK': 'pacific', 'HI': 'pacific'
        }
    
    def get_region_for_state(self, state_code: str) -> str:
        """Get the demographic region for a state"""
        return self.state_to_region.get(state_code.upper(), 'midwest')  # Default to midwest
    
    def generate_name_for_region(self, region: str, index: int = None) -> Tuple[str, str]:
        """
        Generate a name appropriate for a region
        
        Args:
            region: Regional demographic area
            index: Optional index for deterministic selection
            
        Returns:
            Tuple of (first_name, last_name)
        """
        if region not in self.regional_names:
            region = 'midwest'  # Default fallback
        
        names = self.regional_names[region]
        
        if index is not None:
            # Deterministic selection based on index
            first_name = names['first_names'][index % len(names['first_names'])]
            last_name = names['last_names'][index % len(names['last_names'])]
        else:
            # Random selection
            first_name = random.choice(names['first_names'])
            last_name = random.choice(names['last_names'])
        
        return first_name, last_name
    
    def generate_name_for_state(self, state_code: str, index: int = None) -> Tuple[str, str]:
        """
        Generate a name appropriate for a state's demographics
        
        Args:
            state_code: 2-letter state code
            index: Optional index for deterministic selection
            
        Returns:
            Tuple of (first_name, last_name)
        """
        region = self.get_region_for_state(state_code)
        return self.generate_name_for_region(region, index)
    
    def get_full_name_for_state(self, state_code: str, index: int = None) -> str:
        """
        Get a full name appropriate for a state
        
        Args:
            state_code: 2-letter state code
            index: Optional index for deterministic selection
            
        Returns:
            Full name string
        """
        first_name, last_name = self.generate_name_for_state(state_code, index)
        return f"{first_name} {last_name}"
    
    def get_email_for_name(self, first_name: str, last_name: str, company: str) -> str:
        """
        Generate a professional email address
        
        Args:
            first_name: Professional's first name
            last_name: Professional's last name
            company: Company name
            
        Returns:
            Professional email address
        """
        # Clean company name for domain
        domain = company.lower()
        # Remove common business words and special characters
        remove_words = ['inc', 'llc', 'corp', 'company', 'group', 'services', 'realty', 
                       'real estate', 'title', 'law', 'legal', 'bank', 'credit union']
        for word in remove_words:
            domain = domain.replace(word, '')
        
        # Clean up domain
        domain = ''.join(c for c in domain if c.isalnum() or c in [' ', '-'])
        domain = domain.replace(' ', '').replace('-', '')
        domain = domain.strip()
        
        if not domain:
            domain = 'company'
        
        email = f"{first_name.lower()}.{last_name.lower()}@{domain}.com"
        return email

