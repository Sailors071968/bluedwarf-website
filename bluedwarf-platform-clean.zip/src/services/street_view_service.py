import requests
import base64
from typing import Optional, Dict

class StreetViewService:
    """Service for getting property photographs using Google Street View API"""
    
    def __init__(self):
        # Use the same API key as Places API
        self.api_key = "AIzaSyDe8QxfkBSo2Ids9PWK24-aKgqbI9du9B4"
        self.base_url = "https://maps.googleapis.com/maps/api/streetview"
    
    def get_property_photo(self, address: str, latitude: float = None, longitude: float = None) -> Optional[Dict]:
        """
        Get Street View photo for a property address
        
        Args:
            address: Property address string
            latitude: Optional latitude coordinate
            longitude: Optional longitude coordinate
            
        Returns:
            Dictionary with photo URL and metadata, or None if not available
        """
        
        try:
            # Get precise coordinates using Google Geocoding API for accuracy
            if not latitude or not longitude:
                coords = self._geocode_address(address)
                if coords:
                    latitude, longitude = coords
                else:
                    print(f"Could not geocode address: {address}")
                    return None
            
            # Calculate the best heading to face the property
            best_heading = self._calculate_property_heading(latitude, longitude)
            
            # Build Street View API parameters
            params = {
                'key': self.api_key,
                'size': '640x400',  # High quality image
                'fov': 90,          # Wider field of view to capture property
                'heading': best_heading,  # Calculated heading to face property
                'pitch': -10,       # Slight downward angle to capture building
                'source': 'outdoor' # Prefer outdoor imagery
            }
            
            # Use precise coordinates for accurate property targeting
            params['location'] = f"{latitude},{longitude}"
            
            # Make API request
            street_view_url = f"{self.base_url}?{requests.compat.urlencode(params)}"
            
            # Test if the URL returns a valid image
            response = requests.get(street_view_url)
            
            if response.status_code == 200:
                # Check if we got a valid image (not the "no imagery" placeholder)
                content_type = response.headers.get('content-type', '')
                
                if 'image' in content_type:
                    # Check if it's the "no imagery" placeholder by checking content length
                    # The "no imagery" image is typically small (around 1-2KB)
                    content_length = len(response.content)
                    
                    if content_length > 5000:  # Real street view images are much larger
                        # Return the direct Google Street View URL instead of base64
                        return {
                            'success': True,
                            'image_url': street_view_url,
                            'content_type': content_type,
                            'size': '640x400',
                            'source': 'google_street_view'
                        }
                    else:
                        print(f"Street View: No imagery available for {address} (small image size: {content_length} bytes)")
                        return None
                else:
                    print(f"Street View API returned non-image content: {content_type}")
                    return None
            else:
                print(f"Street View API error: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"Error getting Street View photo: {e}")
            return None
    
    def get_multiple_angles(self, address: str, latitude: float = None, longitude: float = None) -> Dict:
        """
        Get multiple Street View photos from different angles
        
        Args:
            address: Property address string
            latitude: Optional latitude coordinate
            longitude: Optional longitude coordinate
            
        Returns:
            Dictionary with photos from different angles
        """
        
        angles = [
            {'name': 'front', 'heading': 0, 'description': 'Front view'},
            {'name': 'side_right', 'heading': 90, 'description': 'Right side view'},
            {'name': 'back', 'heading': 180, 'description': 'Back view'},
            {'name': 'side_left', 'heading': 270, 'description': 'Left side view'}
        ]
        
        photos = {}
        
        for angle in angles:
            try:
                params = {
                    'key': self.api_key,
                    'size': '400x300',  # Smaller for multiple views
                    'fov': 80,
                    'heading': angle['heading'],
                    'pitch': 0,
                    'source': 'outdoor'
                }
                
                if latitude and longitude:
                    params['location'] = f"{latitude},{longitude}"
                else:
                    params['location'] = address
                
                response = requests.get(self.base_url, params=params)
                
                if response.status_code == 200:
                    content_type = response.headers.get('content-type', '')
                    
                    if 'image' in content_type:
                        image_base64 = base64.b64encode(response.content).decode('utf-8')
                        
                        photos[angle['name']] = {
                            'image_url': f"data:{content_type};base64,{image_base64}",
                            'description': angle['description'],
                            'heading': angle['heading']
                        }
                        
            except Exception as e:
                print(f"Error getting {angle['name']} view: {e}")
                continue
        
        return photos
    
    def check_street_view_availability(self, address: str, latitude: float = None, longitude: float = None) -> bool:
        """
        Check if Street View imagery is available for a location
        
        Args:
            address: Property address string
            latitude: Optional latitude coordinate
            longitude: Optional longitude coordinate
            
        Returns:
            True if Street View imagery is available, False otherwise
        """
        
        try:
            # Use Street View Static API metadata endpoint
            metadata_url = "https://maps.googleapis.com/maps/api/streetview/metadata"
            
            params = {
                'key': self.api_key,
                'source': 'outdoor'
            }
            
            if latitude and longitude:
                params['location'] = f"{latitude},{longitude}"
            else:
                params['location'] = address
            
            response = requests.get(metadata_url, params=params)
            
            if response.status_code == 200:
                data = response.json()
                return data.get('status') == 'OK'
            else:
                return False
                
        except Exception as e:
            print(f"Error checking Street View availability: {e}")
            return False
    
    def _geocode_address(self, address: str) -> Optional[tuple]:
        """
        Get precise coordinates for an address using Google Geocoding API
        
        Args:
            address: Property address string
            
        Returns:
            Tuple of (latitude, longitude) or None if geocoding fails
        """
        
        try:
            geocode_url = "https://maps.googleapis.com/maps/api/geocode/json"
            params = {
                'address': address,
                'key': self.api_key
            }
            
            response = requests.get(geocode_url, params=params)
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get('results'):
                    location = data['results'][0]['geometry']['location']
                    return (location['lat'], location['lng'])
                else:
                    print(f"No geocoding results for address: {address}")
                    return None
            else:
                print(f"Geocoding API error: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"Error geocoding address: {e}")
            return None
    
    def _calculate_property_heading(self, latitude: float, longitude: float) -> int:
        """
        Calculate the best heading to face the property from the street
        
        Args:
            latitude: Property latitude
            longitude: Property longitude
            
        Returns:
            Heading in degrees (0-360) to face the property
        """
        
        try:
            # Get Street View metadata to find the actual camera position
            metadata_url = "https://maps.googleapis.com/maps/api/streetview/metadata"
            params = {
                'location': f"{latitude},{longitude}",
                'key': self.api_key,
                'source': 'outdoor'
            }
            
            response = requests.get(metadata_url, params=params)
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get('status') == 'OK' and 'location' in data:
                    # Get the actual Street View camera position
                    camera_lat = data['location']['lat']
                    camera_lng = data['location']['lng']
                    
                    # Calculate heading from camera position to property
                    import math
                    
                    # Convert to radians
                    lat1 = math.radians(camera_lat)
                    lat2 = math.radians(latitude)
                    lng1 = math.radians(camera_lng)
                    lng2 = math.radians(longitude)
                    
                    # Calculate bearing from camera to property
                    dlon = lng2 - lng1
                    y = math.sin(dlon) * math.cos(lat2)
                    x = math.cos(lat1) * math.sin(lat2) - math.sin(lat1) * math.cos(lat2) * math.cos(dlon)
                    
                    bearing = math.atan2(y, x)
                    bearing = math.degrees(bearing)
                    bearing = (bearing + 360) % 360  # Normalize to 0-360
                    
                    return int(bearing)
                else:
                    # Fallback: try multiple common headings
                    return self._find_best_heading_fallback(latitude, longitude)
            else:
                # Fallback: try multiple common headings
                return self._find_best_heading_fallback(latitude, longitude)
                
        except Exception as e:
            print(f"Error calculating property heading: {e}")
            # Default fallback heading
            return 45  # Northeast, common for residential properties
    
    def _find_best_heading_fallback(self, latitude: float, longitude: float) -> int:
        """
        Fallback method to find the best heading by testing multiple angles
        
        Args:
            latitude: Property latitude
            longitude: Property longitude
            
        Returns:
            Best heading in degrees
        """
        
        # Test common property-facing headings
        test_headings = [0, 45, 90, 135, 180, 225, 270, 315]  # N, NE, E, SE, S, SW, W, NW
        
        for heading in test_headings:
            # Test if this heading provides good imagery
            metadata_url = "https://maps.googleapis.com/maps/api/streetview/metadata"
            params = {
                'location': f"{latitude},{longitude}",
                'heading': heading,
                'key': self.api_key,
                'source': 'outdoor'
            }
            
            try:
                response = requests.get(metadata_url, params=params)
                if response.status_code == 200:
                    data = response.json()
                    if data.get('status') == 'OK':
                        # Return the first working heading
                        return heading
            except:
                continue
        
        # Ultimate fallback
        return 45  # Northeast

