from flask import Blueprint, request, jsonify
import sys
import os
import random

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from src.services.zip_lookup_service import ZipCodeLookupService
from src.services.area_code_service import AreaCodeService
from src.services.company_generator import RegionalCompanyGenerator
from src.services.name_generator import ProfessionalNameGenerator
from src.services.property_estimator import PropertyValueEstimator
from src.services.google_places_service import GooglePlacesService
from src.services.professional_processor import ProfessionalDataProcessor
from src.services.fallback_strategy import FallbackStrategyService
from src.services.street_view_service import StreetViewService

property_bp = Blueprint('property', __name__)

# Initialize services
zip_lookup = ZipCodeLookupService()
area_code_service = AreaCodeService()
company_generator = RegionalCompanyGenerator()
name_generator = ProfessionalNameGenerator()
property_estimator = PropertyValueEstimator()
google_places = GooglePlacesService()
professional_processor = ProfessionalDataProcessor()
fallback_strategy = FallbackStrategyService(google_places)
street_view_service = StreetViewService()

@property_bp.route('/analyze', methods=['POST'])
def analyze_property():
    try:
        data = request.get_json()
        address = data.get('address', '').strip()
        
        if not address:
            return jsonify({'error': 'Address is required'}), 400
        
        print(f"Analyzing property: {address}")
        
        # Get coordinates and location info
        try:
            location_info = zip_lookup.get_location_info(address)
            print(f"Location info: {location_info}")
        except Exception as e:
            print(f"Error in zip lookup: {str(e)}")
            return jsonify({'error': f'Zip lookup error: {str(e)}'}), 500
            
        if not location_info:
            return jsonify({'error': 'Could not find location information for this address'}), 400
        
        city = location_info['city']
        state = location_info['state']
        zip_code = location_info['zip_code']
        coordinates = location_info['coordinates']
        
        print(f"Searching for professionals near {city}, {state} ({coordinates['latitude']}, {coordinates['longitude']})")
        
        # Search for professionals
        all_professionals = []
        
        try:
            # Search for each type of professional using fallback strategy
            for category in ['agent', 'lender', 'attorney', 'title']:
                print(f"Searching for {category} professionals...")
                try:
                    # Try Google Places search first
                    professionals = google_places.search_professionals(
                        coordinates['latitude'], 
                        coordinates['longitude'], 
                        category
                    )
                    
                    if professionals:
                        # Process Google Places results
                        processed_professionals = []
                        for place in professionals:
                            processed_prof = professional_processor.process_google_place(place, category)
                            processed_professionals.append(processed_prof)
                        professionals = processed_professionals
                    else:
                        # Use fallback strategy to generate professionals
                        professionals = fallback_strategy.generate_fallback_professionals(
                            city, state, zip_code, category, 1
                        )
                    
                    print(f"Found {len(professionals)} {category} professionals")
                    all_professionals.extend(professionals[:1])  # Limit to 1 per category
                except Exception as e:
                    print(f"Error searching for {category} professionals: {str(e)}")
                    # Generate fallback professionals on error
                    professionals = fallback_strategy.generate_fallback_professionals(
                        city, state, zip_code, category, 1
                    )
                    all_professionals.extend(professionals)
                    
        except Exception as e:
            print(f"Error in professional search: {str(e)}")
            # Generate fallback professionals for all categories
            for category in ['agent', 'lender', 'attorney', 'title']:
                professionals = fallback_strategy.generate_fallback_professionals(
                    city, state, zip_code, category, 1
                )
                all_professionals.extend(professionals)
        
        # Generate property details
        try:
            estimated_value = property_estimator.estimate_property_value(
                city, state, location_info.get('county')
            )
            
            # Create property details dictionary
            property_details = {
                'estimated_value': estimated_value,
                'price_per_sqft': round(estimated_value / 2000),  # Assume 2000 sq ft average
                'market_status': property_estimator.get_market_description(estimated_value),
                'bedrooms': random.randint(2, 5),
                'bathrooms': round(random.uniform(1.5, 3.5), 1),
                'square_feet': random.randint(1500, 3500),
                'lot_size': round(random.uniform(0.15, 0.5), 2),
                'year_built': random.randint(1970, 2020),
                'property_type': random.choice(['Single Family', 'Townhouse', 'Condo']),
                'garage': f"{random.randint(1, 3)} Car Garage",
                'property_tax': round(estimated_value * 0.012),  # 1.2% property tax
                'hoa_fee': random.randint(50, 200) if random.random() > 0.3 else 0,
                'school_rating': f"{random.randint(6, 10)}/10"
            }
            
            print(f"Property details: {property_details}")
        except Exception as e:
            print(f"Error in property estimation: {str(e)}")
            return jsonify({'error': f'Property estimation error: {str(e)}'}), 500
        
        # Get Street View photo
        try:
            print(f"Getting Street View photo for {address}")
            street_view_photo = street_view_service.get_street_view_photo(
                coordinates['latitude'], 
                coordinates['longitude'], 
                address
            )
            print(f"Street View photo: {street_view_photo}")
        except Exception as e:
            print(f"Error getting Street View photo: {str(e)}")
            # Continue without photo
            street_view_photo = {'success': False, 'message': 'Street View unavailable'}
        
        # Prepare response
        response_data = {
            'property': {
                'address': address,
                'city': city,
                'state': state,
                'zip_code': zip_code,
                'coordinates': coordinates,
                'photo': street_view_photo,
                **property_details
            },
            'professionals': all_professionals
        }
        
        return jsonify(response_data)
        
    except Exception as e:
        print(f"Error analyzing property: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Internal server error: {str(e)}'}), 500

