import random
import re
from typing import Dict, List

class ProfessionalDataProcessor:
    """Process Google Places data into professional profiles"""
    
    def __init__(self):
        # Common professional names by region for realistic name generation
        self.regional_names = {
            'california': {
                'first_names': ['Sarah', 'Michael', 'Jennifer', 'David', 'Lisa', 'Robert', 'Maria', 'James', 'Jessica', 'Christopher'],
                'last_names': ['Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez', 'Hernandez']
            },
            'montana': {
                'first_names': ['John', 'Mary', 'William', 'Patricia', 'James', 'Jennifer', 'Robert', 'Linda', 'Michael', 'Elizabeth'],
                'last_names': ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Miller', 'Davis', 'Wilson', 'Moore', 'Taylor']
            },
            'default': {
                'first_names': ['Alex', 'Jordan', 'Taylor', 'Casey', 'Morgan', 'Riley', 'Avery', 'Quinn', 'Sage', 'Drew'],
                'last_names': ['Anderson', 'Thompson', 'White', 'Harris', 'Martin', 'Jackson', 'Clark', 'Lewis', 'Lee', 'Walker']
            }
        }
        
        # Professional titles by category
        self.professional_titles = {
            'agent': ['Real Estate Agent', 'Realtor', 'Senior Agent', 'Associate Broker'],
            'lender': ['Mortgage Loan Officer', 'Senior Loan Officer', 'Mortgage Specialist', 'Lending Manager'],
            'attorney': ['Real Estate Attorney', 'Property Law Attorney', 'Senior Partner', 'Associate Attorney'],
            'title': ['Title Officer', 'Escrow Officer', 'Senior Title Officer', 'Closing Coordinator']
        }
    
    def process_google_place(self, place: Dict, category: str, region: str = 'default') -> Dict:
        """Convert Google Places data to professional profile"""
        
        # Extract business information
        business_name = place.get('displayName', {}).get('text', '')
        address = place.get('formattedAddress', '')
        phone = place.get('nationalPhoneNumber', '')
        website = place.get('websiteUri', '')
        rating = place.get('rating', 0)
        review_count = place.get('userRatingCount', 0)
        
        # Generate professional name
        professional_name = self.extract_or_generate_professional_name(business_name, region)
        
        # Generate professional email
        email = self.generate_professional_email(professional_name, business_name)
        
        # Get professional title
        title = random.choice(self.professional_titles.get(category, ['Professional']))
        
        # Determine subscription status (mix of premium and free)
        status = 'PREMIUM' if rating >= 4.2 and review_count >= 50 else 'FREE'
        
        return {
            'name': professional_name,
            'title': title,
            'company': business_name,
            'address': address,
            'phone': phone,
            'website': website,
            'email': email,
            'category': category,
            'rating': rating,
            'reviews': review_count,
            'status': status,
            'source': 'Google Places API',
            'verified': True
        }
    
    def extract_or_generate_professional_name(self, business_name: str, region: str) -> str:
        """Extract professional name from business name or generate realistic one"""
        
        # Try to extract personal name from business name
        extracted_name = self._extract_name_from_business(business_name)
        if extracted_name:
            return extracted_name
        
        # Generate realistic name based on region
        return self._generate_regional_name(region)
    
    def _extract_name_from_business(self, business_name: str) -> str:
        """Try to extract a personal name from business name"""
        
        # Common patterns for personal names in business names
        patterns = [
            r'^([A-Z][a-z]+ [A-Z][a-z]+) Real Estate',
            r'^([A-Z][a-z]+ [A-Z][a-z]+) Realty',
            r'^([A-Z][a-z]+ [A-Z][a-z]+) & Associates',
            r'^([A-Z][a-z]+ [A-Z][a-z]+) Law',
            r'^([A-Z][a-z]+ [A-Z][a-z]+) Title',
            r'([A-Z][a-z]+ [A-Z][a-z]+) Team',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, business_name)
            if match:
                return match.group(1)
        
        return None
    
    def _generate_regional_name(self, region: str) -> str:
        """Generate a realistic name based on regional demographics"""
        
        region_key = region.lower() if region.lower() in self.regional_names else 'default'
        names = self.regional_names[region_key]
        
        first_name = random.choice(names['first_names'])
        last_name = random.choice(names['last_names'])
        
        return f"{first_name} {last_name}"
    
    def generate_professional_email(self, professional_name: str, business_name: str) -> str:
        """Generate realistic professional email address"""
        
        # Clean the professional name
        name_parts = professional_name.lower().split()
        if len(name_parts) >= 2:
            first_name = name_parts[0]
            last_name = name_parts[1]
        else:
            first_name = name_parts[0] if name_parts else 'contact'
            last_name = 'professional'
        
        # Extract domain from business name
        domain = self._generate_domain_from_business(business_name)
        
        # Common email patterns
        patterns = [
            f"{first_name}.{last_name}@{domain}",
            f"{first_name}{last_name}@{domain}",
            f"{first_name[0]}{last_name}@{domain}",
            f"{first_name}@{domain}"
        ]
        
        return random.choice(patterns)
    
    def _generate_domain_from_business(self, business_name: str) -> str:
        """Generate email domain from business name"""
        
        # Clean business name for domain
        clean_name = re.sub(r'[^a-zA-Z0-9\s]', '', business_name.lower())
        words = clean_name.split()
        
        # Remove common business words
        business_words = {'real', 'estate', 'realty', 'group', 'company', 'inc', 'llc', 'law', 'title', 'bank', 'credit', 'union'}
        filtered_words = [word for word in words if word not in business_words]
        
        if filtered_words:
            domain_name = ''.join(filtered_words[:2])  # Take first 2 meaningful words
        else:
            domain_name = ''.join(words[:2])  # Fallback to first 2 words
        
        return f"{domain_name}.com"
    
    def process_multiple_professionals(self, places_by_category: Dict[str, List[Dict]], region: str = 'default') -> List[Dict]:
        """Process multiple categories of professionals"""
        
        all_professionals = []
        
        for category, places in places_by_category.items():
            for place in places:
                professional = self.process_google_place(place, category, region)
                all_professionals.append(professional)
        
        return all_professionals
    
    def ensure_category_coverage(self, professionals: List[Dict]) -> List[Dict]:
        """Ensure we have at least one professional from each category"""
        
        required_categories = ['agent', 'lender', 'attorney', 'title']
        
        # Group professionals by category
        professionals_by_category = {}
        for prof in professionals:
            category = prof['category']
            if category not in professionals_by_category:
                professionals_by_category[category] = []
            professionals_by_category[category].append(prof)
        
        # Build final list with one professional per category
        final_professionals = []
        
        for category in required_categories:
            if category in professionals_by_category and professionals_by_category[category]:
                # Use the first real professional found for this category
                final_professionals.append(professionals_by_category[category][0])
            else:
                # Only create placeholder if absolutely no real professionals found
                placeholder = self._create_placeholder_professional(category)
                final_professionals.append(placeholder)
        
        return final_professionals
    
    def _create_placeholder_professional(self, category: str) -> Dict:
        """Create a placeholder professional when no real ones are found"""
        
        category_info = {
            'agent': {'company': 'Local Real Estate Services', 'phone': '(555) 123-4567'},
            'lender': {'company': 'Community Mortgage Services', 'phone': '(555) 234-5678'},
            'attorney': {'company': 'Property Law Associates', 'phone': '(555) 345-6789'},
            'title': {'company': 'Regional Title Services', 'phone': '(555) 456-7890'}
        }
        
        info = category_info[category]
        name = self._generate_regional_name('default')
        
        return {
            'name': name,
            'title': random.choice(self.professional_titles[category]),
            'company': info['company'],
            'address': 'Local Area Office',
            'phone': info['phone'],
            'website': '',
            'email': self.generate_professional_email(name, info['company']),
            'category': category,
            'rating': 4.0,
            'reviews': 25,
            'status': 'FREE',
            'source': 'Placeholder',
            'verified': False
        }

