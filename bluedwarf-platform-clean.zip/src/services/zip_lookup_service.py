"""
Zip Code Lookup Service
Provides fast O(1) lookups for all 41,489 US zip codes
"""

import os
import logging
from typing import Dict, Optional

logger = logging.getLogger(__name__)

class ZipCodeLookupService:
    """Service for looking up geographic information for any US zip code"""
    
    def __init__(self):
        self.zip_data = {}
        self.load_zip_database()
        
    def load_zip_database(self):
        """Load the complete US zip code database into memory"""
        try:
            # Get the path to the data file
            current_dir = os.path.dirname(os.path.abspath(__file__))
            data_file = os.path.join(current_dir, '..', 'data', 'US.txt')
            
            logger.info(f"Loading zip code database from: {data_file}")
            
            with open(data_file, 'r', encoding='utf-8') as f:
                for line in f:
                    parts = line.strip().split('\t')
                    if len(parts) >= 11:
                        country_code = parts[0]
                        zip_code = parts[1]
                        place_name = parts[2]
                        admin_name1 = parts[3]  # State name
                        admin_code1 = parts[4]  # State code
                        admin_name2 = parts[5]  # County name
                        admin_code2 = parts[6]  # County code
                        admin_name3 = parts[7]  # Community
                        admin_code3 = parts[8]  # Community code
                        latitude = float(parts[9]) if parts[9] else 0.0
                        longitude = float(parts[10]) if parts[10] else 0.0
                        
                        self.zip_data[zip_code] = {
                            'city': place_name,
                            'state': admin_code1,
                            'state_name': admin_name1,
                            'county': admin_name2,
                            'county_code': admin_code2,
                            'community': admin_name3,
                            'latitude': latitude,
                            'longitude': longitude
                        }
            
            logger.info(f"Loaded {len(self.zip_data)} zip codes into memory")
            
        except Exception as e:
            logger.error(f"Error loading zip code database: {str(e)}")
            # Fallback to empty dict if loading fails
            self.zip_data = {}
    
    def get_location_info(self, address_or_zip: str) -> Optional[Dict]:
        """
        Get location information for an address or zip code
        
        Args:
            address_or_zip: Full address or 5-digit US zip code
            
        Returns:
            Dict with city, state, county info and coordinates or None if not found
        """
        import re
        
        # Extract zip code from address using regex
        zip_pattern = r'\b(\d{5})\b'
        zip_match = re.search(zip_pattern, address_or_zip)
        
        if zip_match:
            zip_code = zip_match.group(1)
        else:
            # If no zip found, treat the whole string as a zip code
            zip_code = address_or_zip.strip()[:5]
        
        # Look up the zip code in our database
        location_data = self.zip_data.get(zip_code)
        
        if location_data:
            # Return location data with coordinates
            return {
                'city': location_data['city'],
                'state': location_data['state'],
                'state_name': location_data['state_name'],
                'county': location_data['county'],
                'zip_code': zip_code,
                'coordinates': {
                    'latitude': location_data['latitude'],
                    'longitude': location_data['longitude']
                }
            }
        
        return None
    
    def is_valid_zip(self, zip_code: str) -> bool:
        """Check if a zip code exists in our database"""
        clean_zip = zip_code.strip()[:5]
        return clean_zip in self.zip_data
    
    def get_zip_count(self) -> int:
        """Get the total number of zip codes loaded"""
        return len(self.zip_data)
    
    def get_state_zip_codes(self, state_code: str) -> list:
        """Get all zip codes for a specific state"""
        state_zips = []
        for zip_code, info in self.zip_data.items():
            if info['state'] == state_code.upper():
                state_zips.append(zip_code)
        return state_zips
    
    def search_by_city_state(self, city: str, state: str) -> list:
        """Find zip codes for a city/state combination"""
        matches = []
        city_lower = city.lower()
        state_upper = state.upper()
        
        for zip_code, info in self.zip_data.items():
            if (info['city'].lower() == city_lower and 
                info['state'] == state_upper):
                matches.append({
                    'zip_code': zip_code,
                    'city': info['city'],
                    'state': info['state'],
                    'county': info['county']
                })
        
        return matches

