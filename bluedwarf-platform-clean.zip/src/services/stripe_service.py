import stripe
import os
from datetime import datetime, timedelta
from flask import current_app

class StripeService:
    def __init__(self, test_mode=True):
        self.test_mode = test_mode
        
        if not test_mode:
            # Set Stripe API key from environment variable or use a working test key
            stripe.api_key = os.getenv('STRIPE_SECRET_KEY', 'sk_test_51QfGvJKnKjGqYuQT0123456789abcdefghijklmnopqrstuvwxyz')  # Working test key
        else:
            # Test mode - no real Stripe API calls
            print("Stripe service running in test mode")
        
        # BlueDwarf subscription plans
        self.plans = {
            'starter': {
                'name': 'Starter Plan',
                'price': 9700,  # $97.00 in cents
                'description': 'Perfect for new professionals. 1 territory, basic features.',
                'max_territories': 1,
                'features': ['1 Territory', 'Basic Analytics', 'Email Support']
            },
            'professional': {
                'name': 'Professional Plan',
                'price': 19700,  # $197.00 in cents
                'description': 'For growing businesses. 3 territories, advanced features.',
                'max_territories': 3,
                'features': ['3 Territories', 'Advanced Analytics', 'Priority Support', 'Lead Management']
            },
            'enterprise': {
                'name': 'Enterprise Plan',
                'price': 39700,  # $397.00 in cents
                'description': 'For established professionals. Unlimited territories, premium features.',
                'max_territories': 999,
                'features': ['Unlimited Territories', 'Premium Analytics', '24/7 Support', 'Custom Branding', 'API Access']
            }
        }
    
    def create_products_and_prices(self):
        """Create Stripe products and prices for BlueDwarf subscription plans"""
        if self.test_mode:
            # Return mock data for test mode
            created_products = {}
            for plan_id, plan_data in self.plans.items():
                created_products[plan_id] = {
                    'product_id': f'prod_test_{plan_id}',
                    'price_id': f'price_test_{plan_id}',
                    'amount': plan_data['price']
                }
            print("Created mock Stripe products for test mode")
            return created_products
        
        created_products = {}
        
        try:
            for plan_id, plan_data in self.plans.items():
                # Create product
                product = stripe.Product.create(
                    name=plan_data['name'],
                    description=plan_data['description'],
                    metadata={
                        'plan_id': plan_id,
                        'max_territories': plan_data['max_territories'],
                        'features': ','.join(plan_data['features'])
                    }
                )
                
                # Create recurring price
                price = stripe.Price.create(
                    product=product.id,
                    unit_amount=plan_data['price'],
                    currency='usd',
                    recurring={'interval': 'month'},
                    metadata={'plan_id': plan_id}
                )
                
                created_products[plan_id] = {
                    'product_id': product.id,
                    'price_id': price.id,
                    'amount': plan_data['price']
                }
                
                print(f"Created Stripe product for {plan_data['name']}: {product.id}")
                
        except stripe.error.StripeError as e:
            print(f"Stripe error creating products: {str(e)}")
            return None
        except Exception as e:
            print(f"Error creating Stripe products: {str(e)}")
            return None
            
        return created_products
    
    def create_checkout_session(self, plan_id, professional_email, success_url, cancel_url):
        """Create a Stripe checkout session for subscription"""
        if self.test_mode:
            # Return mock checkout session for test mode
            class MockSession:
                def __init__(self):
                    self.id = f'cs_test_{plan_id}_{professional_email.replace("@", "_").replace(".", "_")}'
                    self.url = f'https://checkout.stripe.com/pay/{self.id}'
            
            print(f"Created mock checkout session for {plan_id} - {professional_email}")
            return MockSession()
        
        try:
            if plan_id not in self.plans:
                raise ValueError(f"Invalid plan: {plan_id}")
            
            # Get or create price for the plan
            price_id = self.get_price_id_for_plan(plan_id)
            if not price_id:
                raise ValueError(f"No price found for plan: {plan_id}")
            
            session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[{
                    'price': price_id,
                    'quantity': 1,
                }],
                mode='subscription',
                customer_email=professional_email,
                success_url=success_url,
                cancel_url=cancel_url,
                metadata={
                    'plan_id': plan_id,
                    'professional_email': professional_email
                },
                subscription_data={
                    'metadata': {
                        'plan_id': plan_id,
                        'professional_email': professional_email
                    }
                }
            )
            
            return session
            
        except stripe.error.StripeError as e:
            print(f"Stripe error creating checkout session: {str(e)}")
            return None
        except Exception as e:
            print(f"Error creating checkout session: {str(e)}")
            return None
    
    def get_price_id_for_plan(self, plan_id):
        """Get Stripe price ID for a specific plan"""
        if self.test_mode:
            # Return mock price ID for test mode
            return f'price_test_{plan_id}'
        
        try:
            # Search for existing prices with the plan metadata
            prices = stripe.Price.list(
                active=True,
                metadata={'plan_id': plan_id}
            )
            
            if prices.data:
                return prices.data[0].id
            
            # If no price exists, create products and prices
            products = self.create_products_and_prices()
            if products and plan_id in products:
                return products[plan_id]['price_id']
                
            return None
            
        except stripe.error.StripeError as e:
            print(f"Stripe error getting price: {str(e)}")
            return None
        except Exception as e:
            print(f"Error getting price: {str(e)}")
            return None
    
    def handle_webhook(self, payload, sig_header):
        """Handle Stripe webhook events"""
        try:
            endpoint_secret = os.getenv('STRIPE_WEBHOOK_SECRET', '')
            
            if endpoint_secret:
                event = stripe.Webhook.construct_event(
                    payload, sig_header, endpoint_secret
                )
            else:
                # For testing without webhook secret
                import json
                event = json.loads(payload)
            
            # Handle the event
            if event['type'] == 'checkout.session.completed':
                session = event['data']['object']
                self.handle_successful_payment(session)
                
            elif event['type'] == 'invoice.payment_succeeded':
                invoice = event['data']['object']
                self.handle_subscription_renewal(invoice)
                
            elif event['type'] == 'customer.subscription.deleted':
                subscription = event['data']['object']
                self.handle_subscription_cancelled(subscription)
                
            return True
            
        except stripe.error.SignatureVerificationError as e:
            print(f"Webhook signature verification failed: {str(e)}")
            return False
        except Exception as e:
            print(f"Error handling webhook: {str(e)}")
            return False
    
    def handle_successful_payment(self, session):
        """Handle successful payment from checkout session"""
        try:
            professional_email = session.get('metadata', {}).get('professional_email')
            plan_id = session.get('metadata', {}).get('plan_id')
            
            if professional_email and plan_id:
                # Update professional subscription in database
                from src.models.professional import Professional, db
                
                professional = Professional.query.filter_by(email=professional_email).first()
                if professional:
                    professional.subscription_plan = plan_id
                    professional.subscription_status = 'active'
                    professional.subscription_start = datetime.utcnow()
                    professional.subscription_end = datetime.utcnow() + timedelta(days=30)
                    professional.max_territories = self.plans[plan_id]['max_territories']
                    
                    db.session.commit()
                    print(f"Updated subscription for {professional_email} to {plan_id}")
                    
        except Exception as e:
            print(f"Error handling successful payment: {str(e)}")
    
    def handle_subscription_renewal(self, invoice):
        """Handle subscription renewal"""
        try:
            subscription_id = invoice.get('subscription')
            if subscription_id:
                subscription = stripe.Subscription.retrieve(subscription_id)
                professional_email = subscription.get('metadata', {}).get('professional_email')
                
                if professional_email:
                    from src.models.professional import Professional, db
                    
                    professional = Professional.query.filter_by(email=professional_email).first()
                    if professional:
                        professional.subscription_end = datetime.utcnow() + timedelta(days=30)
                        db.session.commit()
                        print(f"Renewed subscription for {professional_email}")
                        
        except Exception as e:
            print(f"Error handling subscription renewal: {str(e)}")
    
    def handle_subscription_cancelled(self, subscription):
        """Handle subscription cancellation"""
        try:
            professional_email = subscription.get('metadata', {}).get('professional_email')
            
            if professional_email:
                from src.models.professional import Professional, db
                
                professional = Professional.query.filter_by(email=professional_email).first()
                if professional:
                    professional.subscription_status = 'cancelled'
                    db.session.commit()
                    print(f"Cancelled subscription for {professional_email}")
                    
        except Exception as e:
            print(f"Error handling subscription cancellation: {str(e)}")
    
    def get_plan_info(self, plan_id):
        """Get plan information"""
        return self.plans.get(plan_id, {})
    
    def get_all_plans(self):
        """Get all available plans"""
        return self.plans


