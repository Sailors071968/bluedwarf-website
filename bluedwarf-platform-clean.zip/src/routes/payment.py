from flask import Blueprint, request, jsonify, current_app
import stripe
import os
import sys

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from src.services.stripe_service import StripeService
from src.models.professional import Professional, db

payment_bp = Blueprint('payment', __name__)
stripe_service = StripeService()

@payment_bp.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
    """Create a Stripe checkout session for subscription"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['plan_id', 'professional_email']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        plan_id = data['plan_id']
        professional_email = data['professional_email']
        
        # Validate plan exists
        if plan_id not in stripe_service.get_all_plans():
            return jsonify({'error': 'Invalid plan selected'}), 400
        
        # Verify professional exists
        professional = Professional.query.filter_by(email=professional_email).first()
        if not professional:
            return jsonify({'error': 'Professional not found'}), 404
        
        # Create success and cancel URLs
        base_url = request.host_url.rstrip('/')
        success_url = f"{base_url}/payment-success?session_id={{CHECKOUT_SESSION_ID}}"
        cancel_url = f"{base_url}/payment-cancelled"
        
        # Create checkout session
        session = stripe_service.create_checkout_session(
            plan_id=plan_id,
            professional_email=professional_email,
            success_url=success_url,
            cancel_url=cancel_url
        )
        
        if not session:
            return jsonify({'error': 'Failed to create checkout session'}), 500
        
        return jsonify({
            'checkout_url': session.url,
            'session_id': session.id
        }), 200
        
    except Exception as e:
        print(f"Error creating checkout session: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@payment_bp.route('/webhook', methods=['POST'])
def stripe_webhook():
    """Handle Stripe webhook events"""
    try:
        payload = request.get_data()
        sig_header = request.headers.get('Stripe-Signature')
        
        if stripe_service.handle_webhook(payload, sig_header):
            return jsonify({'status': 'success'}), 200
        else:
            return jsonify({'error': 'Webhook verification failed'}), 400
            
    except Exception as e:
        print(f"Error handling webhook: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@payment_bp.route('/plans', methods=['GET'])
def get_plans():
    """Get all available subscription plans"""
    try:
        plans = stripe_service.get_all_plans()
        
        # Format plans for frontend
        formatted_plans = {}
        for plan_id, plan_data in plans.items():
            formatted_plans[plan_id] = {
                'id': plan_id,
                'name': plan_data['name'],
                'price': plan_data['price'] / 100,  # Convert cents to dollars
                'price_cents': plan_data['price'],
                'description': plan_data['description'],
                'max_territories': plan_data['max_territories'],
                'features': plan_data['features']
            }
        
        return jsonify({'plans': formatted_plans}), 200
        
    except Exception as e:
        print(f"Error getting plans: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@payment_bp.route('/subscription-status/<professional_email>', methods=['GET'])
def get_subscription_status(professional_email):
    """Get subscription status for a professional"""
    try:
        professional = Professional.query.filter_by(email=professional_email).first()
        if not professional:
            return jsonify({'error': 'Professional not found'}), 404
        
        return jsonify({
            'subscription_plan': professional.subscription_plan,
            'subscription_status': professional.subscription_status,
            'subscription_start': professional.subscription_start.isoformat() if professional.subscription_start else None,
            'subscription_end': professional.subscription_end.isoformat() if professional.subscription_end else None,
            'max_territories': professional.max_territories,
            'territory_count': len(professional.get_territory_zip_codes())
        }), 200
        
    except Exception as e:
        print(f"Error getting subscription status: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@payment_bp.route('/setup-products', methods=['POST'])
def setup_stripe_products():
    """Setup Stripe products and prices (admin endpoint)"""
    try:
        # This endpoint should be protected in production
        products = stripe_service.create_products_and_prices()
        
        if products:
            return jsonify({
                'message': 'Stripe products created successfully',
                'products': products
            }), 200
        else:
            return jsonify({'error': 'Failed to create Stripe products'}), 500
            
    except Exception as e:
        print(f"Error setting up Stripe products: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@payment_bp.route('/payment-success')
def payment_success():
    """Payment success page"""
    session_id = request.args.get('session_id')
    
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Payment Successful - BlueDwarf</title>
        <style>
            body {{ font-family: Arial, sans-serif; text-align: center; padding: 50px; }}
            .success {{ color: #28a745; font-size: 24px; margin-bottom: 20px; }}
            .info {{ color: #6c757d; margin-bottom: 30px; }}
            .button {{ background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; }}
        </style>
    </head>
    <body>
        <h1 class="success">🎉 Payment Successful!</h1>
        <p class="info">Your BlueDwarf subscription has been activated.</p>
        <p class="info">Session ID: {session_id}</p>
        <a href="/" class="button">Return to Dashboard</a>
    </body>
    </html>
    """
    
    return html

@payment_bp.route('/payment-cancelled')
def payment_cancelled():
    """Payment cancelled page"""
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Payment Cancelled - BlueDwarf</title>
        <style>
            body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
            .cancelled { color: #dc3545; font-size: 24px; margin-bottom: 20px; }
            .info { color: #6c757d; margin-bottom: 30px; }
            .button { background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; }
        </style>
    </head>
    <body>
        <h1 class="cancelled">❌ Payment Cancelled</h1>
        <p class="info">Your payment was cancelled. You can try again anytime.</p>
        <a href="/professionals.html" class="button">Back to Plans</a>
    </body>
    </html>
    """
    
    return html

