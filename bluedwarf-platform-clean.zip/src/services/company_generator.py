"""
Regional Company Generator
Generates realistic company names for any US city/state combination
"""

import random
from typing import List, Dict

class RegionalCompanyGenerator:
    """Generates realistic company names based on location"""
    
    def __init__(self):
        # National company templates that can be localized
        self.company_templates = {
            'agent': {
                'national_brands': [
                    'Keller Williams', 'Coldwell Banker', 'RE/MAX', 'Compass',
                    'Century 21', 'Berkshire Hathaway', 'Sotheby\'s International',
                    'Realty One Group', 'eXp Realty', 'Better Homes and Gardens'
                ],
                'regional_patterns': [
                    '{brand} {city}',
                    '{brand} {state}',
                    '{brand} Metro {city}',
                    '{brand} Greater {city}',
                    '{city} {brand}',
                    '{brand} {city} Area'
                ],
                'local_patterns': [
                    '{city} Real Estate',
                    '{city} Realty Group',
                    '{city} Property Partners',
                    'Premier {city} Realty',
                    '{city} Home Experts',
                    'Elite {city} Properties'
                ]
            },
            'lender': {
                'national_brands': [
                    'Wells Fargo', 'Bank of America', 'Chase', 'US Bank',
                    'Citibank', 'PNC Bank', 'TD Bank', 'Regions Bank',
                    'Fifth Third Bank', 'KeyBank', 'Huntington Bank'
                ],
                'regional_patterns': [
                    '{brand} {city}',
                    '{brand} {state}',
                    '{brand} {city} Branch',
                    '{brand} Metro {city}',
                    '{city} {brand}',
                    '{brand} {city} Mortgage'
                ],
                'local_patterns': [
                    '{city} Credit Union',
                    '{city} Community Bank',
                    'First {city} Bank',
                    '{city} Federal Credit Union',
                    '{state} Trust Bank',
                    '{city} Savings Bank'
                ]
            },
            'attorney': {
                'national_brands': [
                    'Stewart Law Group', 'First American Legal',
                    'Fidelity Legal Services', 'Chicago Title Legal'
                ],
                'regional_patterns': [
                    '{brand} {city}',
                    '{brand} {state}',
                    '{city} {brand}',
                    '{brand} Metro {city}'
                ],
                'local_patterns': [
                    '{city} Real Estate Law',
                    '{city} Property Legal Group',
                    '{state} Real Estate Legal',
                    '{city} Title Law',
                    '{city} Legal Services',
                    'Law Offices of {city}',
                    '{city} Property Counsel'
                ]
            },
            'title': {
                'national_brands': [
                    'First American Title', 'Stewart Title', 'Fidelity National Title',
                    'Chicago Title', 'Old Republic Title', 'WFG National Title'
                ],
                'regional_patterns': [
                    '{brand} {city}',
                    '{brand} {state}',
                    '{city} {brand}',
                    '{brand} Metro {city}',
                    '{brand} of {city}'
                ],
                'local_patterns': [
                    '{city} Title Company',
                    '{city} Abstract & Title',
                    '{state} Title Services',
                    '{city} Escrow & Title',
                    'Premier {city} Title',
                    '{city} Title Insurance'
                ]
            }
        }
        
        # Special city name handling for better company names
        self.city_modifiers = {
            'Saint': 'St.',
            'Fort': 'Ft.',
            'Mount': 'Mt.'
        }
    
    def clean_city_name(self, city: str) -> str:
        """Clean city name for use in company names"""
        # Handle common abbreviations
        for full, abbrev in self.city_modifiers.items():
            if city.startswith(full + ' '):
                city = city.replace(full + ' ', abbrev + ' ')
        
        # Remove common suffixes that don't work well in company names
        suffixes_to_remove = [' city', ' town', ' village', ' borough']
        city_lower = city.lower()
        for suffix in suffixes_to_remove:
            if city_lower.endswith(suffix):
                city = city[:-len(suffix)]
        
        return city
    
    def generate_companies_for_location(self, city: str, state: str, category: str) -> List[str]:
        """
        Generate realistic company names for a location and category
        
        Args:
            city: City name
            state: State code (e.g., 'CA')
            category: Professional category ('agent', 'lender', 'attorney', 'title')
            
        Returns:
            List of 4-6 realistic company names
        """
        if category not in self.company_templates:
            return [f"Generic {category.title()} Company"]
        
        template = self.company_templates[category]
        companies = []
        
        # Clean the city name
        clean_city = self.clean_city_name(city)
        
        # Generate 2 national brand companies with regional names
        national_brands = random.sample(template['national_brands'], min(2, len(template['national_brands'])))
        for brand in national_brands:
            pattern = random.choice(template['regional_patterns'])
            company_name = pattern.format(brand=brand, city=clean_city, state=state)
            companies.append(company_name)
        
        # Generate 2-3 local companies
        local_count = random.randint(2, 3)
        for _ in range(local_count):
            pattern = random.choice(template['local_patterns'])
            company_name = pattern.format(city=clean_city, state=state)
            companies.append(company_name)
        
        # Add one more national brand if we need more companies
        if len(companies) < 4:
            remaining_brands = [b for b in template['national_brands'] if b not in national_brands]
            if remaining_brands:
                brand = random.choice(remaining_brands)
                pattern = random.choice(template['regional_patterns'])
                company_name = pattern.format(brand=brand, city=clean_city, state=state)
                companies.append(company_name)
        
        return companies[:6]  # Return max 6 companies
    
    def get_company_for_professional(self, city: str, state: str, category: str, index: int = 0) -> str:
        """
        Get a specific company for a professional (deterministic based on index)
        
        Args:
            city: City name
            state: State code
            category: Professional category
            index: Index for deterministic selection
            
        Returns:
            Company name
        """
        companies = self.generate_companies_for_location(city, state, category)
        if not companies:
            return f"{city} {category.title()} Services"
        
        # Use modulo to ensure we always get a valid company
        return companies[index % len(companies)]

